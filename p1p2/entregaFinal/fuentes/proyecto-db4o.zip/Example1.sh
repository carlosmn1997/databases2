java -cp ./CLASSES:./LIB/db4o-8.0.249.16098-all-java5.jar Example1

