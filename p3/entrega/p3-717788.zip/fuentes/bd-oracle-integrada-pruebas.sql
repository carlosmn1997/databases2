SELECT *
FROM PoseeGlobal
WHERE ROWNUM <=20;

SELECT *
FROM ClienteGlobal;

SELECT *
FROM OpEfectivoGlobal;
